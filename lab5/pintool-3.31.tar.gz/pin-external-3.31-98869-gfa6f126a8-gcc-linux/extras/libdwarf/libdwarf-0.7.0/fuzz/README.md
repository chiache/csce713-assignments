#  libdwarf-code/fuzz

This directory contains source files which
are used in testing (by libdwarf-regressiontests/)
and by oss-fuzz automated testing.

None of these are part of dwarfdump or libdwarf
or any of the sources actually compiled
inside libdwarf-code.
