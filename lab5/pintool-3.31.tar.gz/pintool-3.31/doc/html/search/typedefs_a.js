var searchData=
[
  ['physical_5fcontext_2242',['PHYSICAL_CONTEXT',['../group__PHYSICAL__CONTEXT.html#ga3c6833a027db42b5d528a0c65cefbc07',1,'types_vmapi.PH']]],
  ['pin_5fcallback_2243',['PIN_CALLBACK',['../group__PIN__CALLBACKS.html#ga80ecde10e25aa90133f29e875d21d61d',1,'pin_client.PH']]],
  ['pin_5fconfiguration_5finfo_2244',['PIN_CONFIGURATION_INFO',['../group__PIN__CONTROL.html#ga943bbe3eeb81be27f127382e4b3f82bb',1,'pin_client.PH']]],
  ['pin_5fmutex_2245',['PIN_MUTEX',['../group__LOCK.html#ga217cbb364b3339e20d2d3f3fbe0bb712',1,'lock.PH']]],
  ['pin_5frwmutex_2246',['PIN_RWMUTEX',['../group__LOCK.html#ga34b6e9367817716d0b85f804fba4ffea',1,'lock.PH']]],
  ['pin_5fsemaphore_2247',['PIN_SEMAPHORE',['../group__LOCK.html#ga483703255c7ea848f92a84df4768495e',1,'lock.PH']]],
  ['pin_5fthread_5fuid_2248',['PIN_THREAD_UID',['../group__THREADS.html#ga057233f26b54f23b1ddb0c0c5e31dba9',1,'types_vmapi.PH']]],
  ['prepare_5ffor_5ffini_5fcallback_2249',['PREPARE_FOR_FINI_CALLBACK',['../group__PIN__CONTROL.html#ga47618aec52f2e6918ca0ffce8fefabde',1,'pin_client.PH']]],
  ['proto_2250',['PROTO',['../group__PROTO.html#ga554ff954c3ea33bb537f30e3b500ef1c',1,'types_vmapi.PH']]]
];
