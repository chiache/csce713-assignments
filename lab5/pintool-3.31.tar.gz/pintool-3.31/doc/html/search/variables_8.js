var searchData=
[
  ['native_2189',['native',['../structCALL__APPLICATION__FUNCTION__PARAM.html#acc98ab4c8cf0f5ae1b671aa3a610de34',1,'CALL_APPLICATION_FUNCTION_PARAM']]],
  ['num_5fcontext_5fint_5fregs_2190',['NUM_CONTEXT_INT_REGS',['../group__CONTEXT.html#gab6031aa9d9115234b9c49c6d5ab6d9fa',1,'reg_ia32.PH']]],
  ['num_5fcontext_5fregs_2191',['NUM_CONTEXT_REGS',['../group__CONTEXT.html#ga565196a3eaf9539660ef24845ca8c967',1,'reg_ia32.PH']]],
  ['num_5fspecial_5fregs_2192',['NUM_SPECIAL_REGS',['../group__CONTEXT.html#gaead9b5f2f3655bbaf2776ad99e2ad279',1,'reg_ia32.PH']]],
  ['num_5ftile_5fand_5fcfg_5fregs_2193',['NUM_TILE_AND_CFG_REGS',['../group__CONTEXT.html#ga67017a2889bb2234e34bd3a943c94bfe',1,'reg_ia32.PH']]],
  ['num_5ftile_5fregs_2194',['NUM_TILE_REGS',['../group__CONTEXT.html#ga47e2bd8a7244f986c5a007bd7070f851',1,'reg_ia32.PH']]]
];
