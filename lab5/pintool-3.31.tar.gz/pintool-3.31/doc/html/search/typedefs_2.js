var searchData=
[
  ['child_5fprocess_2215',['CHILD_PROCESS',['../group__PIN__PROCESS.html#ga9830f4f81eb0f4cab7b66cf6c51ac89a',1,'child_process_client.PH']]],
  ['context_2216',['CONTEXT',['../group__CONTEXT.html#ga73f8f88949aaecf53a6d23f56399c676',1,'types_vmapi.PH']]],
  ['context_5fchange_5fcallback_2217',['CONTEXT_CHANGE_CALLBACK',['../group__PIN__CONTROL.html#gaf00c74890a27774b6f9dad0f8267b720',1,'pin_client.PH']]]
];
