var searchData=
[
  ['generic_20modification_20api_2719',['Generic modification API',['../group__INS__MODIFICATION.html',1,'']]]
];
