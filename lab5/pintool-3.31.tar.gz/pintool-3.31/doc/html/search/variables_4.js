var searchData=
[
  ['fpstate_5falignment_2157',['FPSTATE_ALIGNMENT',['../group__CONTEXT.html#ga0f5ad5017cf79566f740ff72e37dfeec',1,'FPSTATE_ALIGNMENT():&#160;fpstate_ia32.PH'],['../group__CONTEXT.html#ga0f5ad5017cf79566f740ff72e37dfeec',1,'FPSTATE_ALIGNMENT():&#160;fpstate_ia32e.PH']]],
  ['fpstate_5fsize_2158',['FPSTATE_SIZE',['../group__CONTEXT.html#gaaf302a6d2cb4e89c0355540b1b0951d7',1,'FPSTATE_SIZE():&#160;fpstate_ia32.PH'],['../group__CONTEXT.html#gaaf302a6d2cb4e89c0355540b1b0951d7',1,'FPSTATE_SIZE():&#160;fpstate_ia32e.PH']]]
];
