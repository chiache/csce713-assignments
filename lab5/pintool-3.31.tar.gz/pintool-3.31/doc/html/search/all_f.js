var searchData=
[
  ['opcode_5fstringshort_639',['OPCODE_StringShort',['../group__INS__INSPECTION.html#gaf5f24968bc08823284ca34b5b05e02ac',1,'ins_api_xed_ia32.PH']]],
  ['open_640',['Open',['../classLOGFILE.html#ac0beeea6ef7460d95ddd8a99b14f5ba6',1,'LOGFILE']]],
  ['operator_2b_2b_641',['operator++',['../group__REG.html#ga9caca16b8d040ff70f0e9538cd9b49b5',1,'operator++(REG &amp;r):&#160;reg_ia32.PH'],['../group__REG.html#ga559cfaa6e729862537689cf0bf21eb4e',1,'operator++(REG &amp;r, int):&#160;reg_ia32.PH']]],
  ['operator_2d_2d_642',['operator--',['../group__REG.html#ga6edb494e507cec5325fbaf67ee1efb2e',1,'reg_ia32.PH']]],
  ['optional_5fvalue_643',['OPTIONAL_VALUE',['../structOPTIONAL__VALUE.html',1,'']]],
  ['optional_5fvalue_3c_20addrint_20_3e_644',['OPTIONAL_VALUE&lt; ADDRINT &gt;',['../structOPTIONAL__VALUE.html',1,'']]],
  ['os_5fprocess_5fid_645',['OS_PROCESS_ID',['../group__THREADS.html#ga2bf6029042d57fb825536c795c94d1ed',1,'types_vmapi.PH']]],
  ['os_5fthread_5fid_646',['OS_THREAD_ID',['../group__THREADS.html#ga1c9cdcd6c1baf15e17c2eb305a16e25e',1,'types_vmapi.PH']]],
  ['out_5fof_5fmemory_5fcallback_647',['OUT_OF_MEMORY_CALLBACK',['../group__PIN__CONTROL.html#gafdfc14fff9d077c1c56019a71763d30f',1,'pin_client.PH']]]
];
