var searchData=
[
  ['invalid_5fos_5fthread_5fid_2159',['INVALID_OS_THREAD_ID',['../group__THREADS.html#gafb51a301378b609eaeffa48de3355945',1,'types_vmapi.PH']]],
  ['invalid_5fpin_5fthread_5fuid_2160',['INVALID_PIN_THREAD_UID',['../group__THREADS.html#gadea3bf4ebf6808cbc830c0735c9285ad',1,'types_vmapi.PH']]],
  ['invalid_5fthreadid_2161',['INVALID_THREADID',['../group__THREADS.html#ga6f1b19d7792c8c6f4547fd9d3dabb427',1,'types_vmapi.PH']]],
  ['invalid_5ftls_5fkey_2162',['INVALID_TLS_KEY',['../group__THREADS.html#gac20e94689fb8467e0309ed7bc0410654',1,'tls.PH']]]
];
