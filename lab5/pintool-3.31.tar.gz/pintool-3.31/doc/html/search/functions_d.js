var searchData=
[
  ['numberofknobs_1730',['NumberOfKnobs',['../group__KNOBS.html#ga6ea4921d7034f43bb963f4f90b6399dc',1,'KNOB_BASE']]],
  ['numofelements_1731',['NumOfElements',['../classIMULTI__ELEMENT__OPERAND.html#a9540e7ff0b5c79096a2b2dc62d7ff8e9',1,'IMULTI_ELEMENT_OPERAND::NumOfElements()'],['../classISCATTERED__MEMORY__REWRITE.html#ad98e8ac391d205490dbe82b2a61c095b',1,'ISCATTERED_MEMORY_REWRITE::NumOfElements()']]]
];
