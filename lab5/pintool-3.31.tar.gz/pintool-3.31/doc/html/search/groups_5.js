var searchData=
[
  ['fast_20buffering_20apis_2718',['Fast Buffering APIs',['../group__BUFFER.html',1,'']]]
];
