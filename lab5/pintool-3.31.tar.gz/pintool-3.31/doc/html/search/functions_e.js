var searchData=
[
  ['opcode_5fstringshort_1732',['OPCODE_StringShort',['../group__INS__INSPECTION.html#gaf5f24968bc08823284ca34b5b05e02ac',1,'ins_api_xed_ia32.PH']]],
  ['open_1733',['Open',['../classLOGFILE.html#ac0beeea6ef7460d95ddd8a99b14f5ba6',1,'LOGFILE']]],
  ['operator_2b_2b_1734',['operator++',['../group__REG.html#ga9caca16b8d040ff70f0e9538cd9b49b5',1,'operator++(REG &amp;r):&#160;reg_ia32.PH'],['../group__REG.html#ga559cfaa6e729862537689cf0bf21eb4e',1,'operator++(REG &amp;r, int):&#160;reg_ia32.PH']]],
  ['operator_2d_2d_1735',['operator--',['../group__REG.html#ga6edb494e507cec5325fbaf67ee1efb2e',1,'reg_ia32.PH']]]
];
