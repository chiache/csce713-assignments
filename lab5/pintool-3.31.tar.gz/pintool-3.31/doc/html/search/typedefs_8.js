var searchData=
[
  ['memory_5faddr_5ftrans_5fcallback_2237',['MEMORY_ADDR_TRANS_CALLBACK',['../group__PIN__CONTROL.html#ga3a5f26e35e32bc5e99d101995339bd73',1,'pin_client.PH']]],
  ['message_5fcallback_2238',['MESSAGE_CALLBACK',['../group__MESSAGE.html#gaddbdb603ecc23c5f2c1aed799c413280',1,'message.PH']]]
];
