var searchData=
[
  ['vstate_5fpadding_2209',['VSTATE_PADDING',['../group__CONTEXT.html#gad1b665d43ed8655d42cf86e474ceb5ea',1,'VSTATE_PADDING():&#160;fpstate_ia32.PH'],['../group__CONTEXT.html#gad1b665d43ed8655d42cf86e474ceb5ea',1,'VSTATE_PADDING():&#160;fpstate_ia32e.PH']]],
  ['vsyscall_5fnr_2210',['VSYSCALL_NR',['../group__INS__INSPECTION.html#ga5da3b48943c5402e8abfe5876525529c',1,'ins.PH']]]
];
