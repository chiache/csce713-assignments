var searchData=
[
  ['reg_3a_20register_20object_2739',['REG: Register Object',['../group__REG.html',1,'']]],
  ['replay_2740',['REPLAY',['../group__REPLAY.html',1,'']]],
  ['rtn_3a_20routine_20object_2741',['RTN: Routine Object',['../group__RTN.html',1,'']]]
];
