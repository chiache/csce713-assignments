var searchData=
[
  ['command_20line_20switches_2713',['Command Line Switches',['../group__CL__OPTIONS.html',1,'']]],
  ['context_20manipulation_20api_2714',['Context manipulation API',['../group__CONTEXT.html',1,'']]],
  ['controlling_20and_20initializing_2715',['Controlling and Initializing',['../group__PIN__CONTROL.html',1,'']]]
];
