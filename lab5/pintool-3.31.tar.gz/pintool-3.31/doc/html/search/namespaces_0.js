var searchData=
[
  ['level_5fbase_1439',['LEVEL_BASE',['../namespaceLEVEL__BASE.html',1,'']]]
];
