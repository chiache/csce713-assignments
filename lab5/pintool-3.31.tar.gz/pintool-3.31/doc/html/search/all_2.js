var searchData=
[
  ['bbl_3a_20single_20entrance_2c_20single_20exit_20sequence_20of_20instructions_55',['BBL: Single entrance, single exit sequence of instructions',['../group__BBL.html',1,'']]],
  ['bbl_5faddress_56',['BBL_Address',['../group__BBL.html#gaa7aa68a764898661e115091ba524c6ba',1,'image.PH']]],
  ['bbl_5fhasfallthrough_57',['BBL_HasFallThrough',['../group__BBL.html#ga49b398eb9c10ff80019315d6c2eee84a',1,'pin_client.PH']]],
  ['bbl_5finsertcall_58',['BBL_InsertCall',['../group__BBL.html#ga9b7dabce7f0343da16e3be0bde9fd393',1,'pin_client.PH']]],
  ['bbl_5finsertifcall_59',['BBL_InsertIfCall',['../group__BBL.html#gaee158afc4efc9224e85435aa55214272',1,'pin_client.PH']]],
  ['bbl_5finsertthencall_60',['BBL_InsertThenCall',['../group__BBL.html#gaa868ef612bc1020554d64b1558cc7cc6',1,'pin_client.PH']]],
  ['bbl_5finshead_61',['BBL_InsHead',['../group__BBL.html#gade725392ec92f3042e8c5b980ca61a8a',1,'image.PH']]],
  ['bbl_5finstail_62',['BBL_InsTail',['../group__BBL.html#ga2740970dd7511488ba2aea081b9298ca',1,'image.PH']]],
  ['bbl_5fnext_63',['BBL_Next',['../group__BBL.html#ga79b074eb89b45ec1cf8e0aa9532b9581',1,'image.PH']]],
  ['bbl_5fnumins_64',['BBL_NumIns',['../group__BBL.html#gac7ea1e91e10bce868bbce497cacabab3',1,'bbl.PH']]],
  ['bbl_5foriginal_65',['BBL_Original',['../group__BBL.html#gad0a08cca57fae0af6ca98f1002a067bf',1,'image.PH']]],
  ['bbl_5fprev_66',['BBL_Prev',['../group__BBL.html#ga24f17f1c38cee6deb1ac18c8465d6fc0',1,'image.PH']]],
  ['bbl_5fsettargetversion_67',['BBL_SetTargetVersion',['../group__TRACE__VERSION.html#ga5fe8277b551bc9a3e6d9b516f39729bd',1,'versions_client.PH']]],
  ['bbl_5fsize_68',['BBL_Size',['../group__BBL.html#gafc9ce3354eb08c36f2ff849e170e182c',1,'image.PH']]],
  ['bbl_5fvalid_69',['BBL_Valid',['../group__BBL.html#gacb48343e32bd7a793b487224ac857b19',1,'image.PH']]],
  ['bitcount_70',['BitCount',['../group__UTILS.html#gabc67f68f3113fe069626ec8c8441aad7',1,'util.PH']]],
  ['buffer_5fid_71',['BUFFER_ID',['../group__BUFFER.html#gaee232a4179b4897b5869a6d5fc98d032',1,'types_vmapi.PH']]],
  ['buffer_5fid_5finvalid_72',['BUFFER_ID_INVALID',['../group__BUFFER.html#gaf379010b4b5cf3316089bb041ce5c02b',1,'types_vmapi.PH']]]
];
