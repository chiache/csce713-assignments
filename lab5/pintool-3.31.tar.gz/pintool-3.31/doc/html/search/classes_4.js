var searchData=
[
  ['exception_5finfo_1404',['EXCEPTION_INFO',['../structEXCEPTION__INFO.html',1,'']]],
  ['exception_5fspecific_1405',['EXCEPTION_SPECIFIC',['../unionEXCEPTION__INFO_1_1EXCEPTION__SPECIFIC.html',1,'EXCEPTION_INFO']]]
];
