var searchData=
[
  ['buffer_5fid_5finvalid_2155',['BUFFER_ID_INVALID',['../group__BUFFER.html#gaf379010b4b5cf3316089bb041ce5c02b',1,'types_vmapi.PH']]]
];
