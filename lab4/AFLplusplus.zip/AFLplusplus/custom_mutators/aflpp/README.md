# custom mutator: AFL++

this is the AFL++ havoc mutator as a custom mutator module for AFL++.

just type `make` to build

```AFL_CUSTOM_MUTATOR_LIBRARY=custom_mutators/aflpp/aflpp-mutator.so afl-fuzz ...```

