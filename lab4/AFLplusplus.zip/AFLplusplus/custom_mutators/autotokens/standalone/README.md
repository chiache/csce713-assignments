# Autotokens standalone mutator

this is a standalone version of the AFL++ autotokens custom mutator.

just type `make` to build.

You *MUST* use a dictionary file to have an effective grammarless grammar fuzzer!

```
autotokens-standalone -h # to see all parameters
autotokens-standalone -x foo.dict inputfile outputfile # example
```
