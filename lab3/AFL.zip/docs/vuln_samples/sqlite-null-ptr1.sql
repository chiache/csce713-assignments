create table t0(t);insert into t0
select strftime();
